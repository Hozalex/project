package HomeWorkNine;

import javax.swing.*;

public class Slider extends JSlider {


    public Slider(int min, int max, int value, String name) {
        super(min, max, value);
        setName(name);

    }


}
