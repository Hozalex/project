package HomeWorkNine;

public class Main {
    public static void main(String[] args) {

        ColorFrame frame = new ColorFrame("Palette");
        frame.initFrame();

    }
}
