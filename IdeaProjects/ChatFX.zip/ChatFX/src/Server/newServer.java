package Server;

import java.sql.SQLException;

public class newServer {
    public static void main(String[] args) throws SQLException {
        new Server();
    }
}
