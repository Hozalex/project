package org.orangecorn.alarm;

import android.os.Build;
import android.speech.tts.TextToSpeech;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Locale;

public class MainActivity extends AppCompatActivity {


    EditText dayEditText;
    EditText timeEditText;
    EditText alarmText;
    Button btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btn = findViewById(R.id.button);
        alarmText = findViewById(R.id.alarmText);


    }


    public void press(View view) {
        AlarmSpeech speech = new AlarmSpeech(alarmText, btn);

    }


}
