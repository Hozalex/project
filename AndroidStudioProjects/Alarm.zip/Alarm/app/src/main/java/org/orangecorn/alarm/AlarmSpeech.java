package org.orangecorn.alarm;

import android.speech.tts.TextToSpeech;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.util.Locale;

public class AlarmSpeech extends AppCompatActivity {
    TextToSpeech tts;
    String defaultText = "Ты че, решил ко мне лезть. а ну иди сюда, мать твою...";
    String toSpeak;
    EditText alarmText;


    public AlarmSpeech(EditText text, Button btn) {

        alarmText = text;

        tts = new TextToSpeech(getApplicationContext(), new TextToSpeech.OnInitListener()

        {
            @Override
            public void onInit(int status) {
                if (status != TextToSpeech.ERROR) {
                    tts.setLanguage(Locale.getDefault());

                }
            }
        });

        btn.setOnClickListener(new View.OnClickListener()

        {
            @Override
            public void onClick(View v) {
                if (alarmText.length() == 0) {
                    toSpeak = defaultText;
                } else toSpeak = alarmText.getText().toString();
//                Toast.makeText(getApplicationContext(), toSpeak, Toast.LENGTH_SHORT).show();
                tts.speak(toSpeak, TextToSpeech.QUEUE_FLUSH, null);
            }
        });

    }

    public void onPause() {
        if (tts != null) {
            tts.stop();
            tts.shutdown();

        }

        super.onPause();
    }

}
